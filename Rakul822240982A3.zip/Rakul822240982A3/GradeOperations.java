/******************************************************
*Name: Rakul Mahenthiran
*Date: Mar 29, 2014
*Program: CENG310
*Program: Interface to compare student marks
******************************************************/

public interface GradeOperations
{
 boolean isEqual(CalculateGrade g);
 boolean isGreater (CalculateGrade g);
 boolean isLess (CalculateGrade g);
}
